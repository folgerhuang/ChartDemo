﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraBars.Helpers;
using DevExpress.Skins;
using DevExpress.LookAndFeel;
using DevExpress.UserSkins;


namespace TreeDemo
{
    public partial class Form1 : RibbonForm
    {
        private enum Weather { 晴天 = 0, 降温 = 1, 寒潮 = 2 };
        public Form1()
        {
            InitializeComponent();
            InitSkinGallery();
            InitTreeListControl();

        }

        /// <summary>
        /// 初始化ColumnEdit的imageComboBox控件与枚举类型
        /// weatherd的关系
        /// </summary>
        private void InitColumnEdit()
        {
            repositoryItemImageComboBox2.Items.AddEnum(typeof(Weather));
            repositoryItemImageComboBox2.Items[0].ImageIndex=0;
            repositoryItemImageComboBox2.Items[1].ImageIndex=1;
            repositoryItemImageComboBox2.Items[2].ImageIndex = 2;    
	
        }

        private void InitTreeCheckedTree()
        {
            ArrayList pList = new ArrayList();

            TestTreeList p = new TestTreeList();

            p.Name = "测试1";

            p.IsChecked = true;

            p.ID = 1;

            pList.Add(p);

            TestTreeList q = new TestTreeList();

            q.Name = "测试2";

            q.IsChecked = false;

            q.ParentID = 1;

            q.ID = 2;

            pList.Add(q);

            this.treeList1.DataSource = pList;

            this.treeList1.RefreshDataSource();


        }
        void InitSkinGallery()
        {
            SkinHelper.InitSkinGallery(rgbiSkins, true);
        }
        void InitTreeListControl()
        {
            Projects projects = InitData();
            DataBinding(projects);
        }
        Projects InitData()
        {
            Projects projects = new Projects();
            projects.Add(new Project("Project A", false));
            projects.Add(new Project("Project B", false));
            projects[0].Projects.Add(new Project("Task 1", true));
            projects[0].Projects.Add(new Project("Task 2", true));
            projects[0].Projects.Add(new Project("Task 3", true));
            projects[0].Projects.Add(new Project("Task 4", true));
            projects[1].Projects.Add(new Project("Task 1", true));
            projects[1].Projects.Add(new Project("Task 2", true));
            return projects;
        }
        void DataBinding(Projects projects)
        {
            treeList.ExpandAll();
            treeList.DataSource = projects;
            treeList.BestFitColumns();
        }

        private void iExit_ItemClick(object sender, ItemClickEventArgs e)
        {
            this.Close();
        }

        private void iOpen_ItemClick(object sender, ItemClickEventArgs e)
        {
            OpenFileDialog opd = new OpenFileDialog();
            opd.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitColumnEdit();
            this.treeList2.AppendNode(new object[] { "2010.1.22", Weather.降温 }, null);
            this.treeList2.AppendNode(new object[] { "2010.1.23", Weather.晴天 }, null);
            this.treeList2.AppendNode(new object[] { "2010.1.24", Weather.寒潮 }, null);

            InitTreeCheckedTree();
        }

        private void treeList_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                treeList.ContextMenuStrip = null;
                MessageBox.Show("CouseClied");
              
               
            }

        }

        private void iAbout_ItemClick(object sender, ItemClickEventArgs e)
        {
            MessageBox.Show("help information!");
        }

       
    }
}